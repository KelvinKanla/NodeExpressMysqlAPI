const mysql = require('./db')
const expressParam = require('../express')

async function getStudents(){
    console.log("About to retrieve students!")
    const query = 'SELECT * FROM Students'
    const studentsDB = await mysql.queryResult(query,[])
    console.log('List of students', studentsDB)
    return studentsDB;


}
async function getOneStudent(student_id){
    console.log("About to retrieve one student!")
    // var student_id = req.params['id']
    const query = 'SELECT * FROM Students  WHERE student_id = ' + student_id;
    console.log("This is the query...", query)
    const studentsDB = await mysql.queryResult(query,[])
    console.log("Student's details", studentsDB)
    return studentsDB;
}

async function createStudent(studentsData){
    console.log("About to create a student!", studentsData)
    
    // const {first_name, last_name, Level, DOB, Entry_year} = studentsData;
    console.log("Service Student data: ", studentsData)
    const query = 'INSERT INTO Students SET ?';
    let record = await mysql.queryResult(query, [studentsData])
    console.log("Records: ", record)
    return studentsData;
    
}


module.exports = {
    getStudents,
    getOneStudent,
    createStudent
}