const mysql = require('./db')

async function getStudent(){
    console.log("About to retrieve students!")
    const query = 'SELECT * FROM Students'
    const studentsDB = await mysql.queryResult(query,[])
    console.log('List of students', studentsDB)
    return studentsDB;


}
module.exports = {
    getStudent
}