const express = require('express');
const app = express();
const studentController = require('./controllers/students.controller')

app.get('/students',async (req,res)=>{

console.log("request from server",req);
const results = await studentController.index();

return res.status(200).json({message: "successs",data: results});
})


app.get('/', (req, res)=>{
    console.log("request from server", req);
    
    const {query} = req
    console.log("request from server",query);
    return res.status(200).json({message: "new successs"});
})

// Start the server
app.listen(3000, () => console.log('Server started on port 3000'));