const studentData = require('../services/students.service')

async function index () {
    try {
        const results =  await studentData.getStudent();
        console.log("results from students services",results)
        return results;
    } catch (error) {
        console.log("an error occurred",[error])

        throw error;
    }

}

module.exports = {
    index
}